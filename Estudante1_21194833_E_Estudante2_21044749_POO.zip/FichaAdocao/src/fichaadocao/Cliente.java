/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fichaadocao;

/**
 *
 * @author lab801
 */
public class Cliente {

    private String nome;
    private String endereco;
    private String celular;
    private int idade;
    private String identidadeDeGenero;
    private String CPF;

    public void setNome(String umNome) {
        this.nome = umNome;
    }

    public void setEndereco(String umEndereco) {
        this.endereco = umEndereco;
    }

    public void setCelular(String umCelular) {
        this.celular = umCelular;
    }

    public void setIdade(int umaIdade) {
        this.idade = umaIdade;
    }

    public void setIdentidadeDeGenero(String umaIdentidadeDeGenero) {
        this.identidadeDeGenero = umaIdentidadeDeGenero;
    }
    
     public void setCPF(String umCPF) {
        this.CPF = umCPF;
    }

    public String getNome() {
        return this.nome;
    }

    public String getEndereco() {
        return this.endereco;
    }

    public String getCelular() {
        return this.celular;
    }

    public int getIdade() {
        return this.idade;
    }

    public String getIdentidadeDeGenero() {
        return this.identidadeDeGenero;
    }

    public String getCPF() {
        return this.CPF;
    }
}
