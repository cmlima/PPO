/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fichaadocao;

/**
 *
 * @author lab801
 */
public class FichaAdocao {

    private String horarioAdocao;
    private String nomeAtendente;
    private Cliente cliente;
    private Cao caoAdotado;

    public void setHorarioAdocao(String umHorarioAdocao) {
        this.horarioAdocao = umHorarioAdocao;
    }

    public void setNomeAtendente(String umNomeAtendente) {
        this.nomeAtendente = umNomeAtendente;
    }

    public void setCliente(Cliente umCliente) {
        this.cliente = umCliente;
    }

    public void setCaoAdotado(Cao umCao) { 
        this.caoAdotado = umCao;
    }
    public String getHorarioAdocao() {
        return this.horarioAdocao;
    }

    public String getNomeAtendente() {
        return this.nomeAtendente;
    }

    public Cliente getCliente() {
        return this.cliente;
    }

    public Cao getCaoAdotado() {
        return this.caoAdotado;
    }

}
