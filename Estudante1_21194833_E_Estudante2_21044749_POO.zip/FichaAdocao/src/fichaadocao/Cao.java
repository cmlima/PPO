/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fichaadocao;

/**
 *
 * @author lab801
 */
public class Cao {

    private String nome;
    private String cor;
    private String raca;
    private int idade;
    private String caracteristicaMarcante;

    public void setNome(String umNome) {
        this.nome = umNome;
    }

    public void setCor(String umaCor) {
        this.cor = umaCor;
    }

    public void setRaca(String umaRaca) {
        this.raca = umaRaca;
    }

    public void setIdade(int umaIdade) {
        this.idade = umaIdade;
    }

    public void setCaracteristicaMarcante(String umaCaracteristicaMarcante) {
        this.caracteristicaMarcante = umaCaracteristicaMarcante;
    }

    public String getNome() {
        return this.nome;
    }

    public String getCor() {
        return this.cor;
    }

    public String getRaca() {
        return this.raca;
    }

    public int getIdade() {
        return this.idade;
    }

    public String getCaracteristicaMarcante() {
        return this.caracteristicaMarcante;
    }

}
